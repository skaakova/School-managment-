-- Запусти это в своей базе school_db !
-- Это таблица для логина в API

CREATE TABLE IF NOT EXISTS users (
    id         SERIAL PRIMARY KEY,
    username   VARCHAR(50) UNIQUE NOT NULL,
    password   VARCHAR(255) NOT NULL,
    role       VARCHAR(20) NOT NULL CHECK (role IN ('admin', 'teacher'))
);

-- После запуска зарегистрируй admin через POST /auth/register
-- или вставь через API
