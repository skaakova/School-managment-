-- ================================================
-- SCHOOL MANAGEMENT SYSTEM — твоя реальная схема
-- Запускай только если базы ещё нет!
-- ================================================

CREATE TABLE Teachers (
    id      SERIAL PRIMARY KEY,
    name    VARCHAR(100) NOT NULL,
    subject VARCHAR(50)  NOT NULL
);

CREATE TABLE Classes (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(50) NOT NULL,
    teacher_id INT REFERENCES Teachers(id)
);

CREATE TABLE Students (
    id       SERIAL PRIMARY KEY,
    name     VARCHAR(100) NOT NULL,
    age      INT CHECK (age > 5),
    class_id INT REFERENCES Classes(id)
);

CREATE TABLE Subjects (
    id   SERIAL PRIMARY KEY,
    name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE Grades (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES Students(id),
    subject_id INT REFERENCES Subjects(id),
    grade      INT CHECK (grade BETWEEN 0 AND 100)
);

CREATE TABLE Attendance (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES Students(id),
    date       DATE NOT NULL,
    status     VARCHAR(20)
);

CREATE TABLE Parents (
    id         SERIAL PRIMARY KEY,
    name       VARCHAR(100),
    student_id INT REFERENCES Students(id)
);

CREATE TABLE MedicalInfo (
    id         SERIAL PRIMARY KEY,
    student_id INT REFERENCES Students(id),
    blood_type VARCHAR(10),
    allergies  TEXT
);

CREATE TABLE Courses (
    id          SERIAL PRIMARY KEY,
    course_name VARCHAR(100)
);

CREATE TABLE CourseSubjects (
    id         SERIAL PRIMARY KEY,
    course_id  INT REFERENCES Courses(id),
    subject_id INT REFERENCES Subjects(id)
);
