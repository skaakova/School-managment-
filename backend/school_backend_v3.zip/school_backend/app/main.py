from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.routers.auth            import router as auth_router
from app.routers.students        import router as students_router
from app.routers.teachers        import router as teachers_router
from app.routers.classes         import router as classes_router
from app.routers.grades          import router as grades_router
from app.routers.attendance      import router as attendance_router
from app.routers.subjects_courses import subjects_router, courses_router
from app.routers.parents_medical import parents_router, medical_router

app = FastAPI(
    title="🏫 School Management System",
    description="REST API для управления школой — студенты, учителя, оценки, посещаемость.",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth_router)
app.include_router(students_router)
app.include_router(teachers_router)
app.include_router(classes_router)
app.include_router(grades_router)
app.include_router(attendance_router)
app.include_router(subjects_router)
app.include_router(courses_router)
app.include_router(parents_router)
app.include_router(medical_router)


@app.get("/", tags=["Health"])
def root():
    return {"status": "✅ работает", "docs": "http://localhost:8000/docs"}
