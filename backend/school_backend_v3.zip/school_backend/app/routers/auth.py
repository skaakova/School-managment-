from fastapi import APIRouter, Depends, HTTPException
from fastapi.security import OAuth2PasswordRequestForm
from app.core.database import get_db
from app.core.auth import verify_password, create_token, hash_password
from pydantic import BaseModel

router = APIRouter(prefix="/auth", tags=["🔐 Auth"])


class RegisterBody(BaseModel):
    username: str
    password: str
    role: str  # "admin" или "teacher"


@router.post("/login", summary="Войти и получить токен")
def login(form: OAuth2PasswordRequestForm = Depends(), db=Depends(get_db)):
    cur = db.cursor()
    cur.execute("SELECT * FROM users WHERE username = %s", (form.username,))
    user = cur.fetchone()
    if not user or not verify_password(form.password, user["password"]):
        raise HTTPException(401, "Неверный логин или пароль")
    token = create_token({"sub": str(user["id"]), "role": user["role"], "username": user["username"]})
    return {"access_token": token, "token_type": "bearer", "role": user["role"]}


@router.post("/register", status_code=201, summary="Зарегистрировать пользователя")
def register(body: RegisterBody, db=Depends(get_db)):
    if body.role not in ("admin", "teacher"):
        raise HTTPException(400, "Роль должна быть admin или teacher")
    cur = db.cursor()
    cur.execute("SELECT id FROM users WHERE username = %s", (body.username,))
    if cur.fetchone():
        raise HTTPException(400, "Такой username уже занят")
    cur.execute(
        "INSERT INTO users (username, password, role) VALUES (%s,%s,%s) RETURNING id, username, role",
        (body.username, hash_password(body.password), body.role),
    )
    result = cur.fetchone()
    db.commit()
    return result
