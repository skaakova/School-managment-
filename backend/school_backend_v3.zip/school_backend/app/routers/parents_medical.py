from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

# ── PARENTS ───────────────────────────────────────────────────────────────────

parents_router = APIRouter(prefix="/parents", tags=["👨‍👩‍👦 Parents"])


class ParentCreate(BaseModel):
    name: str
    student_id: int


@parents_router.get("/", summary="Все родители")
def list_parents(db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("""
        SELECT p.id, p.name, s.name AS student
        FROM parents p JOIN students s ON s.id = p.student_id
        ORDER BY p.name
    """)
    return cur.fetchall()


@parents_router.post("/", status_code=201, summary="Добавить родителя")
def create_parent(body: ParentCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("INSERT INTO parents (name, student_id) VALUES (%s,%s) RETURNING *", (body.name, body.student_id))
    result = cur.fetchone()
    db.commit()
    return result


@parents_router.delete("/{parent_id}", status_code=204, summary="Удалить родителя")
def delete_parent(parent_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM parents WHERE id = %s RETURNING id", (parent_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Родитель не найден")
    db.commit()


# ── MEDICAL INFO ──────────────────────────────────────────────────────────────

medical_router = APIRouter(prefix="/medical", tags=["🏥 Medical Info"])


class MedicalCreate(BaseModel):
    student_id: int
    blood_type: Optional[str] = None
    allergies: Optional[str] = None


class MedicalUpdate(BaseModel):
    blood_type: Optional[str] = None
    allergies: Optional[str] = None


@medical_router.get("/", summary="Все медицинские записи")
def list_medical(db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("""
        SELECT m.id, s.name AS student, m.blood_type, m.allergies
        FROM medicalinfo m JOIN students s ON s.id = m.student_id
        ORDER BY s.name
    """)
    return cur.fetchall()


@medical_router.post("/", status_code=201, summary="Добавить мед. информацию")
def create_medical(body: MedicalCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute(
        "INSERT INTO medicalinfo (student_id, blood_type, allergies) VALUES (%s,%s,%s) RETURNING *",
        (body.student_id, body.blood_type, body.allergies),
    )
    result = cur.fetchone()
    db.commit()
    return result


@medical_router.put("/{student_id}", summary="Обновить мед. информацию")
def update_medical(student_id: int, body: MedicalUpdate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    fields = {k: v for k, v in body.dict().items() if v is not None}
    if not fields:
        raise HTTPException(400, "Нечего обновлять")
    set_clause = ", ".join(f"{k} = %s" for k in fields)
    cur.execute(f"UPDATE medicalinfo SET {set_clause} WHERE student_id = %s RETURNING *", (*fields.values(), student_id))
    result = cur.fetchone()
    if not result:
        raise HTTPException(404, "Запись не найдена")
    db.commit()
    return result
