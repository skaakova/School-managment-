from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/teachers", tags=["👩‍🏫 Teachers"])


class TeacherCreate(BaseModel):
    name: str
    subject: str


class TeacherUpdate(BaseModel):
    name: Optional[str] = None
    subject: Optional[str] = None


@router.get("/", summary="Список всех учителей")
def list_teachers(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("SELECT * FROM teachers ORDER BY name")
    return cur.fetchall()


@router.get("/{teacher_id}", summary="Один учитель по ID")
def get_teacher(teacher_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("SELECT * FROM teachers WHERE id = %s", (teacher_id,))
    t = cur.fetchone()
    if not t:
        raise HTTPException(404, "Учитель не найден")
    return t


@router.post("/", status_code=201, summary="Добавить учителя")
def create_teacher(body: TeacherCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("INSERT INTO teachers (name, subject) VALUES (%s,%s) RETURNING *", (body.name, body.subject))
    result = cur.fetchone()
    db.commit()
    return result


@router.put("/{teacher_id}", summary="Изменить учителя")
def update_teacher(teacher_id: int, body: TeacherUpdate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    fields = {k: v for k, v in body.dict().items() if v is not None}
    if not fields:
        raise HTTPException(400, "Нечего обновлять")
    set_clause = ", ".join(f"{k} = %s" for k in fields)
    cur.execute(f"UPDATE teachers SET {set_clause} WHERE id = %s RETURNING *", (*fields.values(), teacher_id))
    result = cur.fetchone()
    if not result:
        raise HTTPException(404, "Учитель не найден")
    db.commit()
    return result


@router.delete("/{teacher_id}", status_code=204, summary="Удалить учителя")
def delete_teacher(teacher_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM teachers WHERE id = %s RETURNING id", (teacher_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Учитель не найден")
    db.commit()


@router.get("/{teacher_id}/classes", summary="Классы этого учителя")
def teacher_classes(teacher_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT c.id, c.name,
               COUNT(s.id) AS student_count
        FROM classes c
        LEFT JOIN students s ON s.class_id = c.id
        WHERE c.teacher_id = %s
        GROUP BY c.id ORDER BY c.name
    """, (teacher_id,))
    return cur.fetchall()
