from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from datetime import date
from typing import Optional

router = APIRouter(prefix="/attendance", tags=["📅 Attendance"])


class AttendanceCreate(BaseModel):
    student_id: int
    date: date
    status: str  # present / absent / late


@router.get("/", summary="Вся посещаемость")
def list_attendance(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT a.id, s.name AS student, a.date, a.status
        FROM attendance a
        JOIN students s ON s.id = a.student_id
        ORDER BY a.date DESC
    """)
    return cur.fetchall()


@router.post("/", status_code=201, summary="Отметить посещаемость")
def mark_attendance(body: AttendanceCreate, db=Depends(get_db), _=Depends(require_role("admin", "teacher"))):
    if body.status not in ("present", "absent", "late"):
        raise HTTPException(400, "Статус: present / absent / late")
    cur = db.cursor()
    cur.execute(
        "INSERT INTO attendance (student_id, date, status) VALUES (%s,%s,%s) RETURNING *",
        (body.student_id, body.date, body.status),
    )
    result = cur.fetchone()
    db.commit()
    return result


@router.delete("/{attendance_id}", status_code=204, summary="Удалить запись")
def delete_attendance(attendance_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM attendance WHERE id = %s RETURNING id", (attendance_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Запись не найдена")
    db.commit()


@router.get("/summary/{student_id}", summary="Статистика посещаемости студента")
def attendance_summary(student_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT
            COUNT(*) FILTER (WHERE status = 'present') AS present,
            COUNT(*) FILTER (WHERE status = 'absent')  AS absent,
            COUNT(*) FILTER (WHERE status = 'late')    AS late,
            ROUND(100.0 * COUNT(*) FILTER (WHERE status='present') / NULLIF(COUNT(*),0), 1) AS attendance_pct
        FROM attendance WHERE student_id = %s
    """, (student_id,))
    return cur.fetchone()
