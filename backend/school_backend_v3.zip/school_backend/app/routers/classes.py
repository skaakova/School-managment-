from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/classes", tags=["🏫 Classes"])


class ClassCreate(BaseModel):
    name: str
    teacher_id: Optional[int] = None


@router.get("/", summary="Список всех классов")
def list_classes(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT c.id, c.name, t.name AS teacher, COUNT(s.id) AS students
        FROM classes c
        LEFT JOIN teachers t ON t.id = c.teacher_id
        LEFT JOIN students s ON s.class_id = c.id
        GROUP BY c.id, t.name ORDER BY c.name
    """)
    return cur.fetchall()


@router.get("/{class_id}", summary="Один класс по ID")
def get_class(class_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT c.id, c.name, t.name AS teacher
        FROM classes c LEFT JOIN teachers t ON t.id = c.teacher_id
        WHERE c.id = %s
    """, (class_id,))
    cls = cur.fetchone()
    if not cls:
        raise HTTPException(404, "Класс не найден")
    return cls


@router.post("/", status_code=201, summary="Создать класс")
def create_class(body: ClassCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("INSERT INTO classes (name, teacher_id) VALUES (%s,%s) RETURNING *", (body.name, body.teacher_id))
    result = cur.fetchone()
    db.commit()
    return result


@router.put("/{class_id}", summary="Изменить класс")
def update_class(class_id: int, body: ClassCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("UPDATE classes SET name=%s, teacher_id=%s WHERE id=%s RETURNING *",
                (body.name, body.teacher_id, class_id))
    result = cur.fetchone()
    if not result:
        raise HTTPException(404, "Класс не найден")
    db.commit()
    return result


@router.delete("/{class_id}", status_code=204, summary="Удалить класс")
def delete_class(class_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM classes WHERE id = %s RETURNING id", (class_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Класс не найден")
    db.commit()


@router.get("/{class_id}/students", summary="Студенты в классе")
def class_students(class_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("SELECT id, name, age FROM students WHERE class_id = %s ORDER BY name", (class_id,))
    return cur.fetchall()


@router.get("/{class_id}/grades", summary="Средние оценки по классу")
def class_grades(class_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT s.name AS student,
               ROUND(AVG(g.grade)::numeric, 1) AS average,
               COUNT(g.id) AS total_grades
        FROM students s
        LEFT JOIN grades g ON g.student_id = s.id
        WHERE s.class_id = %s
        GROUP BY s.id ORDER BY average DESC NULLS LAST
    """, (class_id,))
    return cur.fetchall()
