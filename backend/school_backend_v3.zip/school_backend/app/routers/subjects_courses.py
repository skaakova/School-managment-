from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

# ── SUBJECTS ──────────────────────────────────────────────────────────────────

subjects_router = APIRouter(prefix="/subjects", tags=["📚 Subjects"])


class SubjectCreate(BaseModel):
    name: str


@subjects_router.get("/")
def list_subjects(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("SELECT * FROM subjects ORDER BY name")
    return cur.fetchall()


@subjects_router.post("/", status_code=201)
def create_subject(body: SubjectCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("INSERT INTO subjects (name) VALUES (%s) RETURNING *", (body.name,))
    result = cur.fetchone()
    db.commit()
    return result


@subjects_router.delete("/{subject_id}", status_code=204)
def delete_subject(subject_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM subjects WHERE id = %s RETURNING id", (subject_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Предмет не найден")
    db.commit()


# ── COURSES ───────────────────────────────────────────────────────────────────

courses_router = APIRouter(prefix="/courses", tags=["🎓 Courses"])


class CourseCreate(BaseModel):
    course_name: str


class LinkSubject(BaseModel):
    subject_id: int


@courses_router.get("/")
def list_courses(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT co.id, co.course_name,
               array_agg(sub.name ORDER BY sub.name) AS subjects
        FROM courses co
        LEFT JOIN coursesubjects cs ON cs.course_id = co.id
        LEFT JOIN subjects sub ON sub.id = cs.subject_id
        GROUP BY co.id ORDER BY co.course_name
    """)
    return cur.fetchall()


@courses_router.post("/", status_code=201)
def create_course(body: CourseCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("INSERT INTO courses (course_name) VALUES (%s) RETURNING *", (body.course_name,))
    result = cur.fetchone()
    db.commit()
    return result


@courses_router.post("/{course_id}/subjects", status_code=201, summary="Добавить предмет к курсу")
def link_subject(course_id: int, body: LinkSubject, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    try:
        cur.execute(
            "INSERT INTO coursesubjects (course_id, subject_id) VALUES (%s,%s) RETURNING *",
            (course_id, body.subject_id),
        )
        result = cur.fetchone()
        db.commit()
        return result
    except Exception:
        db.rollback()
        raise HTTPException(409, "Предмет уже привязан к этому курсу")


@courses_router.delete("/{course_id}", status_code=204)
def delete_course(course_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM courses WHERE id = %s RETURNING id", (course_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Курс не найден")
    db.commit()
