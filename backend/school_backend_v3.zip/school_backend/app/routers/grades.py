from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/grades", tags=["📝 Grades"])


class GradeCreate(BaseModel):
    student_id: int
    subject_id: int
    grade: int


class GradeUpdate(BaseModel):
    grade: int


@router.get("/", summary="Все оценки")
def list_grades(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT g.id, s.name AS student, sub.name AS subject, g.grade
        FROM grades g
        JOIN students s  ON s.id  = g.student_id
        JOIN subjects sub ON sub.id = g.subject_id
        ORDER BY s.name, sub.name
    """)
    return cur.fetchall()


@router.post("/", status_code=201, summary="Поставить оценку")
def add_grade(body: GradeCreate, db=Depends(get_db), _=Depends(require_role("admin", "teacher"))):
    if not (0 <= body.grade <= 100):
        raise HTTPException(400, "Оценка должна быть от 0 до 100")
    cur = db.cursor()
    cur.execute(
        "INSERT INTO grades (student_id, subject_id, grade) VALUES (%s,%s,%s) RETURNING *",
        (body.student_id, body.subject_id, body.grade),
    )
    result = cur.fetchone()
    db.commit()
    return result


@router.put("/{grade_id}", summary="Изменить оценку")
def update_grade(grade_id: int, body: GradeUpdate, db=Depends(get_db), _=Depends(require_role("admin", "teacher"))):
    cur = db.cursor()
    cur.execute("UPDATE grades SET grade = %s WHERE id = %s RETURNING *", (body.grade, grade_id))
    result = cur.fetchone()
    if not result:
        raise HTTPException(404, "Оценка не найдена")
    db.commit()
    return result


@router.delete("/{grade_id}", status_code=204, summary="Удалить оценку")
def delete_grade(grade_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM grades WHERE id = %s RETURNING id", (grade_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Оценка не найдена")
    db.commit()


@router.get("/report/top", summary="Топ студентов по среднему баллу")
def top_students(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT s.name, c.name AS class_name,
               ROUND(AVG(g.grade)::numeric, 1) AS gpa
        FROM grades g
        JOIN students s ON s.id = g.student_id
        LEFT JOIN classes c ON c.id = s.class_id
        GROUP BY s.id, c.name
        ORDER BY gpa DESC
    """)
    return cur.fetchall()


@router.get("/report/by-subject", summary="Средний балл по каждому предмету")
def grades_by_subject(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT sub.name AS subject,
               ROUND(AVG(g.grade)::numeric, 1) AS avg_grade,
               COUNT(g.id) AS total
        FROM grades g
        JOIN subjects sub ON sub.id = g.subject_id
        GROUP BY sub.id ORDER BY avg_grade DESC
    """)
    return cur.fetchall()
