from fastapi import APIRouter, Depends, HTTPException
from app.core.database import get_db
from app.core.auth import get_current_user, require_role
from pydantic import BaseModel
from typing import Optional

router = APIRouter(prefix="/students", tags=["👨‍🎓 Students"])


class StudentCreate(BaseModel):
    name: str
    age: int
    class_id: Optional[int] = None


class StudentUpdate(BaseModel):
    name: Optional[str] = None
    age: Optional[int] = None
    class_id: Optional[int] = None


# ── GET все студенты ──────────────────────────────────────────────────────────
@router.get("/", summary="Список всех студентов")
def list_students(db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT s.id, s.name, s.age, c.name AS class_name
        FROM students s
        LEFT JOIN classes c ON c.id = s.class_id
        ORDER BY s.name
    """)
    return cur.fetchall()


# ── GET один студент ──────────────────────────────────────────────────────────
@router.get("/{student_id}", summary="Один студент по ID")
def get_student(student_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT s.id, s.name, s.age, c.name AS class_name
        FROM students s
        LEFT JOIN classes c ON c.id = s.class_id
        WHERE s.id = %s
    """, (student_id,))
    s = cur.fetchone()
    if not s:
        raise HTTPException(404, "Студент не найден")
    return s


# ── CREATE ────────────────────────────────────────────────────────────────────
@router.post("/", status_code=201, summary="Добавить студента")
def create_student(body: StudentCreate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute(
        "INSERT INTO students (name, age, class_id) VALUES (%s,%s,%s) RETURNING *",
        (body.name, body.age, body.class_id),
    )
    result = cur.fetchone()
    db.commit()
    return result


# ── UPDATE ────────────────────────────────────────────────────────────────────
@router.put("/{student_id}", summary="Изменить данные студента")
def update_student(student_id: int, body: StudentUpdate, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    fields = {k: v for k, v in body.dict().items() if v is not None}
    if not fields:
        raise HTTPException(400, "Нечего обновлять")
    set_clause = ", ".join(f"{k} = %s" for k in fields)
    cur.execute(f"UPDATE students SET {set_clause} WHERE id = %s RETURNING *", (*fields.values(), student_id))
    result = cur.fetchone()
    if not result:
        raise HTTPException(404, "Студент не найден")
    db.commit()
    return result


# ── DELETE ────────────────────────────────────────────────────────────────────
@router.delete("/{student_id}", status_code=204, summary="Удалить студента")
def delete_student(student_id: int, db=Depends(get_db), _=Depends(require_role("admin"))):
    cur = db.cursor()
    cur.execute("DELETE FROM students WHERE id = %s RETURNING id", (student_id,))
    if not cur.fetchone():
        raise HTTPException(404, "Студент не найден")
    db.commit()


# ── Оценки студента ───────────────────────────────────────────────────────────
@router.get("/{student_id}/grades", summary="Оценки студента")
def student_grades(student_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT g.id, sub.name AS subject, g.grade
        FROM grades g
        JOIN subjects sub ON sub.id = g.subject_id
        WHERE g.student_id = %s
        ORDER BY sub.name
    """, (student_id,))
    return cur.fetchall()


# ── Посещаемость студента ─────────────────────────────────────────────────────
@router.get("/{student_id}/attendance", summary="Посещаемость студента")
def student_attendance(student_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("""
        SELECT id, date, status
        FROM attendance
        WHERE student_id = %s
        ORDER BY date DESC
    """, (student_id,))
    return cur.fetchall()


# ── Родители студента ─────────────────────────────────────────────────────────
@router.get("/{student_id}/parents", summary="Родители студента")
def student_parents(student_id: int, db=Depends(get_db), _=Depends(get_current_user)):
    cur = db.cursor()
    cur.execute("SELECT * FROM parents WHERE student_id = %s", (student_id,))
    return cur.fetchall()


# ── Медицинская информация ────────────────────────────────────────────────────
@router.get("/{student_id}/medical", summary="Медицинская информация")
def student_medical(student_id: int, db=Depends(get_db), _=Depends(require_role("admin", "teacher"))):
    cur = db.cursor()
    cur.execute("SELECT * FROM medicalinfo WHERE student_id = %s", (student_id,))
    info = cur.fetchone()
    if not info:
        raise HTTPException(404, "Медицинская информация не найдена")
    return info
